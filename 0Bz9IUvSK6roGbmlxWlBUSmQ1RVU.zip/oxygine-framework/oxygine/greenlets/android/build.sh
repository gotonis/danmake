#!/bin/sh
#./../../../../android-ndk-r5-crystax-2/ndk-build NDK_PROJECT_PATH=./ $@
./../../../../android-ndk-r7-crystax-4/ndk-build NDK_PROJECT_PATH=./ $@
#./../../../../android-ndk-r5b/ndk-build NDK_PROJECT_PATH=./ $@
