#pragma once
#include "oxygine-framework.h"
using namespace oxygine;
extern Resources res;