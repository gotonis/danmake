#include "shared.h"

Resources res;