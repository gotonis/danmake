package org.oxygine.Match3;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
