#!/bin/bash
adb install -r bin/${PROJECT}-debug.apk
adb shell am start -n org.oxygine.${PROJECT}/org.oxygine.${PROJECT}.MainActivity