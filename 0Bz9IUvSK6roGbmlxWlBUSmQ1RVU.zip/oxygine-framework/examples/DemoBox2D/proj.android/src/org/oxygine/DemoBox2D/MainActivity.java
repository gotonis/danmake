package org.oxygine.DemoBox2D;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
