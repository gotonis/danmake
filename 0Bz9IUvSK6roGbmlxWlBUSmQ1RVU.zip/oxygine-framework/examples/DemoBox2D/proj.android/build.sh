#!/bin/bash
ndk-build NDK_MODULE_PATH=${ROOT} $@