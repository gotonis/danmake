void example_preinit();
void example_init();
void example_update();
void example_destroy();
