package org.oxygine.GamePart4;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
