package org.oxygine.GamePart5;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
