#!/bin/bash
ant debug