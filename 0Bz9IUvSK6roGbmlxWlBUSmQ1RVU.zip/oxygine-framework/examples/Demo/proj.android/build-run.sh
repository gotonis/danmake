#!/bin/bash
sh build.sh
sh ant_debug.sh
sh install.sh