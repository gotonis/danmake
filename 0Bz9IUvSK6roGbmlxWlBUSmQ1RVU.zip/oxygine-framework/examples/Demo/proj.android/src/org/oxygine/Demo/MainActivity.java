package org.oxygine.Demo;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
